from django.http import HttpResponse
from django.shortcuts import render
from chatbot.botfiles import chat as bot
from datetime import date

# Create your views here.


def getChatUi(request):
    htmlData = render(request, "chatbot.html", {
        'nowDate': date.today(),
    })
    return HttpResponse(htmlData)


def sendChatResponse(request):
    getData = request.GET
    print(getData['question'])
    botresponse = bot.talk(getData['question'])
    return HttpResponse(botresponse)
